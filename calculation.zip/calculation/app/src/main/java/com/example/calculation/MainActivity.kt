package com.example.calculation

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize views
        var editTextNum1 = findViewById<EditText>(R.id.EstimatedProfit)
        var editTextNum2 = findViewById<EditText>(R.id.totalExpenses)
        var addButton = findViewById<Button>(R.id.addButton)
        var resultTextView = findViewById<TextView>(R.id.resultTextView)
        var MinimumHourGoals = findViewById<EditText>(R.id.MinimumHourGoals)
        var MaximumHourGoals = findViewById<EditText>(R.id.MaximumHourGoals)

        // Set a click listener for the button
        addButton.setOnClickListener {
            // Get the input from the EditText fields
            val num1 = editTextNum1.text.toString().toIntOrNull() ?: 0
            val num2 = editTextNum2.text.toString().toIntOrNull() ?: 0
            val MaxHGoal = MaximumHourGoals.text.toString().toIntOrNull() ?:0
            val MiniHGoal = MinimumHourGoals.text.toString().toIntOrNull() ?:0


            // Calculate the sum
            val sum = num1 - num2
            val Hoursum = MaxHGoal - MiniHGoal
        }




    }
    }
