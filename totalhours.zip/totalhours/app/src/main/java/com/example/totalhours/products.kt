package com.example.totalhours

data class products(val nameText : String? = null, val categoryText : String? = null, val ageInt : String? = null )
