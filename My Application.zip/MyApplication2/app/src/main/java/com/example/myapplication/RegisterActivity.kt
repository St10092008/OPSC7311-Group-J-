package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.myapplication.LoginActivity.Companion.SHARED_PREFS


class RegisterActivity : AppCompatActivity() {

    private lateinit var sharedpreferences: SharedPreferences
    private var email: String? = null
    private var password: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        sharedpreferences =getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE)

        val emailEdt = findViewById<EditText>(R.id.inputUsername)
        val passwordEdt = findViewById<EditText>(R.id.inputPasswordlog)
        val registerBtn = findViewById<Button>(R.id.btnRegister)

        // calling on click listener for register button.
        registerBtn.setOnClickListener {
            // to check if the user fields are empty or not.
            if (TextUtils.isEmpty(emailEdt.text.toString()) || TextUtils.isEmpty(passwordEdt.text.toString())) {
                // this method will call when email and password fields are empty.
                Toast.makeText(
                    this@RegisterActivity,
                    "Please Enter Both Email and Password",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                val editor = sharedpreferences.edit()

                // below two lines will put values for
                // email and password in shared preferences.
                editor.putString(LoginActivity.EMAIL_KEY, emailEdt.text.toString())
                editor.putString(LoginActivity.PASSWORD_KEY, passwordEdt.text.toString())

                // to save our data with key and value.
                editor.apply()

                // starting new activity.
                val i = Intent(this@RegisterActivity, HomePageActivity::class.java)
                startActivity(i)
                finish()
            }
        }

        val button = findViewById<Button>(R.id.btnAlready)
        button.setOnClickListener {
            // Handle button click

            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}