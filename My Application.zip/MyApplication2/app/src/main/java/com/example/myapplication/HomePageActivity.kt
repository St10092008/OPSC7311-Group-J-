package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class HomePageActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        val button1 = findViewById<Button>(R.id.CreateTimeSheetBtn)
        button1.setOnClickListener {
            // Handle button click
            val intent = Intent(this@HomePageActivity, CreateTimeSheetActivity::class.java)
            startActivity(intent)
        }

        val button2 = findViewById<Button>(R.id.ViewEntryBtn)

        button2.setOnClickListener {
            // Handle button click
            val intent2 = Intent(this@HomePageActivity, ViewActivity::class.java)
            startActivity(intent2)
        }


    }
}