package com.example.myapplication

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class ViewActivity : AppCompatActivity() {
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)

        val print = findViewById<Button>(R.id.printName)

        print.setOnClickListener{

            val db = DBHelper(this, null)

            // below is the variable for cursor
            // we have called method to get
            // all names from our database
            // and add to name text view
            val cursor = db.getName()

            // moving the cursor to first position and
            // appending value in the text view
            cursor!!.moveToFirst()
            findViewById<TextView>(R.id.Name).append(cursor.getString(cursor.getColumnIndex(DBHelper.NAME_COl)) + "\n")
            findViewById<TextView>(R.id.Description).append(cursor.getString(cursor.getColumnIndex(DBHelper.DESCRIPT_COL)) + "\n")
            findViewById<TextView>(R.id.Category).append(cursor.getString(cursor.getColumnIndex(DBHelper.CAT_COL)) + "\n")
            findViewById<TextView>(R.id.sDate).append(cursor.getString(cursor.getColumnIndex(DBHelper.DATE_COL)) + "\n")
            findViewById<TextView>(R.id.eDate).append(cursor.getString(cursor.getColumnIndex(DBHelper.EDATE_COL)) + "\n")

            // moving our cursor to next
            // position and appending values
            while(cursor.moveToNext()){
                findViewById<TextView>(R.id.Name).append(cursor.getString(cursor.getColumnIndex(DBHelper.NAME_COl)) + "\n")
                findViewById<TextView>(R.id.Description).append(cursor.getString(cursor.getColumnIndex(DBHelper.DESCRIPT_COL)) + "\n")
                findViewById<TextView>(R.id.Category).append(cursor.getString(cursor.getColumnIndex(DBHelper.CAT_COL)) + "\n")
                findViewById<TextView>(R.id.sDate).append(cursor.getString(cursor.getColumnIndex(DBHelper.DATE_COL)) + "\n")
                findViewById<TextView>(R.id.eDate).append(cursor.getString(cursor.getColumnIndex(DBHelper.EDATE_COL)) + "\n")
            }

            // at last we close our cursor
            cursor.close()
            this.finish()
        }

    }
}
