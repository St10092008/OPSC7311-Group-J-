package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    // creating constant keys for shared preferences.
    companion object {
        const val SHARED_PREFS = "shared_prefs"
        const val EMAIL_KEY = "email_key"
        const val PASSWORD_KEY = "password_key"
    }

    // variable for shared preferences.
    private lateinit var sharedpreferences: SharedPreferences
    private var email: String? = null
    private var password: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val emailEdt = findViewById<EditText>(R.id.inputUsername)
        val passwordEdt = findViewById<EditText>(R.id.inputPasswordlog)
        val loginBtn = findViewById<Button>(R.id.btn_login)

        // getting the data which is stored in shared preferences.
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE)

        // in shared prefs inside get string method
        // we are passing key value as EMAIL_KEY and
        // default value is
        // set to null if not present.
        email = sharedpreferences.getString("EMAIL_KEY", null)
        password = sharedpreferences.getString("PASSWORD_KEY", null)

        // calling on click listener for login button.
        loginBtn.setOnClickListener {
            // to check if the user fields are empty or not.
            if (TextUtils.isEmpty(emailEdt.text.toString()) || TextUtils.isEmpty(passwordEdt.text.toString())) {
                // this method will call when email and password fields are empty.
                Toast.makeText(this@LoginActivity, "Please Enter Email and Password", Toast.LENGTH_SHORT).show()
            } else {
                //check if the password and email found matches registered value
                if (email.equals(emailEdt.text.toString())&&password.equals(passwordEdt.text.toString())) {
                    //val editor = sharedpreferences.edit()

                    // below two lines will put values for
                    // email and password in shared preferences.
                    //editor.putString(EMAIL_KEY, emailEdt.text.toString())
                    //editor.putString(PASSWORD_KEY, passwordEdt.text.toString())

                    // to save our data with key and value.
                    //editor.apply()

                    // starting new activity.
                    val i = Intent(this@LoginActivity, HomePageActivity::class.java)
                    startActivity(i)
                    finish()
                } else {
                    // this method will call when email and password fields are empty.
                    Toast.makeText(this@LoginActivity, "Password And Email Do Not Match Registred Account", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val button = findViewById<TextView>(R.id.textViewSignUp)
        button.setOnClickListener {
            // Handle button click
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
        }


    }
}