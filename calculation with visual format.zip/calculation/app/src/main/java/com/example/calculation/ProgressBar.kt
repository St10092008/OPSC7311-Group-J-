package com.example.calculation

import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ProgressBar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val FeedCounter :AppCompatActivity

        var progessbtn = findViewById<Button>(R.id.ProgessBtn)

        progessbtn.setOnClickListener{


        }

    }
}